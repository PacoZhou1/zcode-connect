Legacy self-hosted relay kit (V1). ZCode 3.17.1 official Relay V2 additionally requires account/device/token HTTP services. This kit does not implement those services. Do not forward official account credentials to this server.

旧协议自建中转工具包（V1）。它不实现 ZCode 3.17.1 官方 Relay V2 的账号、设备登记及令牌 HTTP 服务。请勿将官方账号凭据发送到自建中转。
